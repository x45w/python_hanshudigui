gl_list = [6, 3, 9]

# 默认按照升序排列 - 可能会更多!
# gl_list.sort()

# 如果需要降序排序,需要执行reverse参数
gl_list.sort(reverse=True)

print(gl_list)